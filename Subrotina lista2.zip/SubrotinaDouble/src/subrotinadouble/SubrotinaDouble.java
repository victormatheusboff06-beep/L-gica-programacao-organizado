package subrotinadouble;

public class SubrotinaDouble {

    static double CM(double[] n) {
        double soma = 0;

        for (int i = 0; i < n.length; i++) {
            soma += n[i];
        }
        return soma / n.length;
    }

    public static void main(String[] args) {
        double[] num = {7.67, 8, 0.5, 6.9};
        
        double media = CM(num);
        System.out.println("A média é: " + media);
    }
    
}
