package subrotinatf;

public class SubrotinaTF {

    static boolean contemNumero(int[] vetor, int numero) {
        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] == numero) {
                return true;
            }
        }

        return false;
    }

    public static void main(String[] args) {
        int[] numeros = {67, 25, 31, 42, 59};
        
        System.out.println(contemNumero(numeros, 5)); 
        
    }
    
}
