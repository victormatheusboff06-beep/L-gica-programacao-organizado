package subrotinavet;

public class SubrotinaVet {

    static int encontrarMaior(int[] v) {
        int maior = v[0];
        for (int i = 1; i < v.length; i++) {
            if (v[i] > maior) {
                maior = v[i];
            }
        }
        return maior;
    }

    public static void main(String[] args) {
        int[] numeros = {1, 45, 7, 29, 2, 34};
        
        int resultado = encontrarMaior(numeros);
        System.out.println("O maior número é: " + resultado);
    }
    
}
