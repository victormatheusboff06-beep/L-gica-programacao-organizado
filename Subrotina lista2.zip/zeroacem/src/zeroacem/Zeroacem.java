/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package zeroacem;

/**
 *
 * @author Victor
 */
public class Zeroacem {

    public static void main(String[] args) {
        System.out.println("a");
        ZAC(0);
    }
    
    static void ZAC(int a) {
        if (a > 100) {
            return;
        }
        System.out.println(a);
        ZAC(a + 1);
    }
}
