package subrotinainverter;

public class SubrotinaInverter {

    static int[] inverter(int[] v) {
        int[] in = new int[v.length];

        for (int i = 0; i < v.length; i++) {
            in[i] = v[v.length - 1 - i];
        }

        return in;
    }

    public static void main(String[] args) {
        int[] num = {1, 2, 3, 4, 5, 6, 7};
        int[] resp = inverter(num);

        for (int i = 0; i < resp.length; i++) {
            System.out.print(resp[i] + " ");
        }
    }
    
}
