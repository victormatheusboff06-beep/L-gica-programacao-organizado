package palindromo;

public class Palindromo {

    static boolean ehPalindromo(String p) {
        
        p = p.toLowerCase();
 
        if (p.length() <= 1) {
            return true;
        }
        if (p.charAt(0) != p.charAt(p.length() - 1)) {
            return false;
        }
        return ehPalindromo(p.substring(1, p.length() - 1));
    }

    public static void main(String[] args) {
        String palavra = "BOB";

        if (ehPalindromo(palavra)) {
            System.out.println(palavra + " é um palíndromo");
        } else {
            System.out.println(palavra + " não é palíndromo");
        }
    }  
}
