package subrotinadel;

public class SubrotinaDel {

    static int[] removerDuplicados(int[] vetor) {
        int[] temp = new int[vetor.length];
        int tU = 0;
        for (int i = 0; i < vetor.length; i++) {
            boolean rep = false;
            for (int j = 0; j < tU; j++) {
                if (vetor[i] == temp[j]) {
                    rep = true;
                    break;
                }
            }
            if (!rep) {
                temp[tU] = vetor[i];
                tU++;
            }
        }
        int[] resp = new int[tU];
        for (int i = 0; i < tU; i++) {
            resp[i] = temp[i];
        }
        return resp;
    }

    public static void main(String[] args) {
        int[] numeros = {42, 22, 67, 42, 9, 67, 10, 7};
        int[] semRepeticao = removerDuplicados(numeros);

        for (int i = 0; i < semRepeticao.length; i++) {
            System.out.print(semRepeticao[i] + " ");
        }
    }
    
}
