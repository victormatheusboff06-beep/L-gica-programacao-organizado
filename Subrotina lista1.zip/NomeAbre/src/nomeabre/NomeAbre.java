/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package nomeabre;

/**
 *
 * @author Victor
 */
public class NomeAbre {

    static String abreviarNome(String nome) {
    String[] part = nome.trim().split(" ");
    String r = part[0];

    for (int i = 1; i < part.length - 1; i++) {
        r += " " + part[i].charAt(0) + ".";
    }

    if (part.length > 1) {
        r += " " + part[part.length - 1];
    }

    return r;
}

    public static void main(String[] args) {
        
        String t = abreviarNome("Victor Matheus Boff");
        System.out.println(t);
    }
    
}
