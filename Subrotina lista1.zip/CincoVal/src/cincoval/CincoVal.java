/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cincoval;

import java.util.Scanner;

public class CincoVal {

    
    public static void main(String[] args) {
       
         Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o 1 número inteiro: ");
        int n1 = scanner.nextInt();

        System.out.print("Digite o 2 número inteiro: ");
        int n2 = scanner.nextInt();

        System.out.print("Digite o 3 número inteiro: ");
        int n3 = scanner.nextInt();

        System.out.print("Digite o 4 número inteiro: ");
        int n4 = scanner.nextInt();

        System.out.print("Digite o 5 número inteiro: ");
        int n5 = scanner.nextInt();

        Verity(n1, n2, n3, n4, n5);

    }

    static void Verity(int a, int b, int c, int d, int e) {
        int[] numeros = {a, b, c, d, e};
        
        int maior = numeros[0];
        int menor = numeros[0];
        
        for (int i = 1; i < numeros.length; i++) {
            if (numeros[i] > maior) {
                maior = numeros[i];
            }
            if (numeros[i] < menor) {
                menor = numeros[i];
            }
        }
        
        System.out.println("O maior valor digitado é: " + maior);
        System.out.println("O menor valor digitado é: " + menor);
    }
    
}
