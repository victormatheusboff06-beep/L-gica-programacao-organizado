/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package conversao;

/**
 *
 * @author Victor
 */
public class Conversao {

    static int converter(int HI, int MI, int HF, int MF) {
        int iTotal = (HI * 60) + MI;
    int fTotal = (HF * 60) + MF;

    if (fTotal <= iTotal) {
        fTotal += 1440;
    }
        
    return fTotal - iTotal;
    }
    
    public static void main(String[] args) {
        
        int total = converter(1, 20, 12, 30);
        System.out.println(total);
    }
    
}
