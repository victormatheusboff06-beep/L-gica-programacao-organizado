
package ex1matrizes;

import java.util.Scanner;

public class Ex1Matrizes {

    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        String a;
        System.out.println("Digite Algo");
        a = sc.nextLine();
        
        int b;
        b = a.length();
        
        System.out.println("oque o usuario escreveu tem " + b + " caracteres");
        
    }
    
}
